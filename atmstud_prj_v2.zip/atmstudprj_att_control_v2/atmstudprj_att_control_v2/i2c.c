#include "i2c.h"

uint8_t I2C_ErrorCode;

void i2c_init(void) {
	switch (PSC_I2C) {
		case 4:
			TWSR = 0x01;
			break;
		case 16:
			TWSR = 0x02;
			break;
		case 64:
			TWSR = 0x03;
			break;
		default:
			TWSR = 0x00;
			break;
	}
	TWBR = (uint8_t)SET_TWBR;
	TWCR = (1 << TWEN); //enable i2c
}

void i2c_start(uint8_t i2c_adr) {
	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
	uint16_t timeout = F_CPU/F_I2C*2.0;
	while((TWCR & (1 << TWINT)) == 0 && timeout != 0) {
		timeout--;
		if(timeout == 0) {
			I2C_ErrorCode |= (1 << I2C_START);
			return;
		}
	};
	// send adress
	TWDR = i2c_adr;
	TWCR = (1 << TWINT)|( 1 << TWEN);
	timeout = F_CPU/F_I2C*2.0;
	while((TWCR & (1 << TWINT)) == 0 &&
	timeout !=0){
		timeout--;
		if(timeout == 0){
			I2C_ErrorCode |= (1 << I2C_SENDADRESS);
			return;
		}
	};
}

void i2c_stop(void) {
	TWSR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
}

void i2c_byte(uint8_t byte) {
	TWDR = byte;
	TWCR = (1 << TWINT) | (1 << TWEN);
	uint16_t timeout = F_CPU/F_I2C*2.0;
	while((TWCR & (1 << TWINT)) == 0 && timeout != 0) {
		timeout--;
		if(timeout == 0) {
			I2C_ErrorCode |= (1 << I2C_BYTE);
			return;
		}
	};
}
