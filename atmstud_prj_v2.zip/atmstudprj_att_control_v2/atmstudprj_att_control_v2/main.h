#ifndef main_h
#define main_h

#ifdef __cplusplus
extern "C" {
#endif

#define F_CPU 12000000UL
#include <stdint.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <math.h>
#include "ssd1306.h"

uint8_t read_gray_code_encoder(void);
void sn74hc259(int num);
void set_sn74hc259_1(void);
void set_sn74hc259_2(void);
void clear_sn74hc259_1(void);
void clear_sn74hc259_2(void);
void set_att_1(int num);
void set_att_2(int num);

#ifdef __cplusplus
}
#endif
#endif

