#include "main.h"

volatile uint8_t val, val_tmp;
volatile uint8_t menuPressed=0;
volatile int8_t i=0, j=0;
volatile char str1[4], str2[4];
unsigned int list_8496h[12]={0,10,20,30,40,50,60,70,80,90,100,110};
unsigned int list_8494h[12]={0,1,2,3,4,5,6,7,8,9,10,11};

void att_int(uint8_t x, uint8_t y) {
	lcd_fillRect(x,y+4, x+2,y+11, WHITE);
	lcd_fillRect(x,y+17, x+2,y+24, WHITE);
	
	lcd_fillRect(x+2,y, x+9,y+2, WHITE);
	lcd_fillRect(x+2,y+13, x+9,y+15, WHITE);
	lcd_fillRect(x+2,y+26, x+9,y+28, WHITE);
	
	lcd_fillRect(x+9,y+4, x+11,y+11, WHITE);
	lcd_fillRect(x+9,y+17, x+11,y+24, WHITE);
}

uint8_t read_gray_code_encoder(void) {
	uint8_t val=0;
	if(!bit_is_clear(PINC,PC0))
		val |= (1<<1);
	if(!bit_is_clear(PINC,PC1))
		val |= (1<<0); 
	return val;
	
	/*if ((PINC & (1 << 0)) == 0 && (PINC & (1 << 1)) == 0) {
	return 0;
	} else if ((PINC & (1 << 0)) == 0 && (PINC & (1 << 1)) == 1) {
	return 1;
	} else if ((PINC & (1 << 0)) == 1 && (PINC & (1 << 1)) == 1) {
	return 2;
	} else {
	return 3;
	}*/
}
/* ----------------------- config timers ------------------------------- */
void init_timer1(void) {
	TCCR1A |= (0<<COM1A1)|(0<<COM1A0);
	TCCR1A |= (0<<COM1B1)|(0<<COM0B0);
	TCCR1A |= (0<<WGM12)|(0<<WGM11)|(0<<WGM10); // normal
	TCCR1B = (1<<CS12)|(0<<CS11)|(0<<CS10);     // prescaler (010:8; 011:64; 100:256)
	TIMSK1 = 1<<TOIE1;                          // Overflow Interrupt Enable
	TIFR1  = 1<<TOV1;                           // Clear overflow flag
}

ISR(TIMER1_OVF_vect) {
	//----------------------- menu --------------------------------------
	if ((PINC & (1 << 2)) == 0 && menuPressed == 0) {
		_delay_ms(50);				// ���������� ��������
		if ((PINC & (1 << 2)) == 0) { // ����� ��������� �������
			menuPressed = 1;
		}
		while((PINC & (1 << 2)) == 0) {} // ���� ���������� ������
	}
	else if ((PINC & (1 << 2)) == 0 && menuPressed == 1) {
		_delay_ms(50);
		if ((PINC & (1 << 2)) == 0) {
			menuPressed = 0;
		}
		while((PINC & (1 << 2)) == 0)
		{}
	}

	if (menuPressed == 0) {
		lcd_drawRect(65, 11, 105, 33, WHITE);
		lcd_drawRect(65, 34, 105, 56, BLACK);
		lcd_display();
	}
	else if (menuPressed == 1) {
		lcd_drawRect(65, 11, 105, 33, BLACK);
		lcd_drawRect(65, 34, 105, 56, WHITE);
		lcd_display();
	}
	//---------------------------- encoder -------------------------------
	val_tmp = read_gray_code_encoder();
	if(val != val_tmp) {
		if (menuPressed == 0) {
			if((val==3 && val_tmp==2)) {
			//if((val==3 && val_tmp==1) || (val==0 && val_tmp==2)) {
				i++;
				if(i>11)
					i=11;
				sprintf(str1, "%3d", list_8496h[i]);
			}
			else if((val==1 && val_tmp==3)) {
			//else if((val==2 && val_tmp==0) || (val==1 && val_tmp==3)) {
				i--;
				if(i<0)
					i=0;
				sprintf(str1, "%3d", list_8496h[i]);
			}
			lcd_charMode(DOUBLESIZE);
			lcd_gotoxy(11,2);
			lcd_puts(str1);
			lcd_display();
			set_att_1(list_8496h[i]);
		}
		else if (menuPressed == 1) {
			if((val==3 && val_tmp==2)) {
				j++;
				if(j>11)
					j=11;
				sprintf(str2, "%3d", list_8494h[j]);
			}
			else if((val==1 && val_tmp==3)) {
				j--;
				if(j<0)
					j=0;
				sprintf(str2, "%3d", list_8494h[j]);
			}
			lcd_charMode(DOUBLESIZE);
			lcd_gotoxy(11,5);
			lcd_puts(str2);
			lcd_display();
			set_att_2(list_8494h[j]);
		}
		val = val_tmp;
	}
	TCNT1 = 65524; // Hz
}
// ---------------------- sn74hc259 -------------------------------
void sn74hc259(int num) {
	if (num == 0) {
		PORTD &= ~ (1<<PD5); // S0
		PORTD &= ~(1<<PD6); // S1
		PORTD &= ~(1<<PD7); // S2
	}
	else if (num == 1) {
		PORTD |= (1<<PD5);
		PORTD &= ~(1<<PD6);
		PORTD &= ~ (1<<PD7);
	}
	else if (num == 2) {
		PORTD &= ~(1<<PD5);
		PORTD |= (1<<PD6);
		PORTD &= ~(1<<PD7);
	}
	else if (num == 3) {
		PORTD |= (1<<PD5);
		PORTD |= (1<<PD6);
		PORTD &= ~(1<<PD7);
	}
	else if (num == 4) {
		PORTD &= ~(1<<PD5);
		PORTD &= ~(1<<PD6);
		PORTD |= (1<<PD7);
	}
	else if (num == 5) {
		PORTD |= (1<<PD5);
		PORTD &= ~(1<<PD6);
		PORTD |= (1<<PD7);
	}
	else if (num == 6) {
		PORTD &= ~(1<<PD5);
		PORTD |= (1<<PD6);
		PORTD |= (1<<PD7);
	}
	else if (num == 7) {
		PORTD |=(1<<PD5);
		PORTD |= (1<<PD6);
		PORTD |= (1<<PD7);
	}
}

int x_db[12][4] = {
	{0, 2, 4, 6}, //0
	{1, 2, 4, 6}, //10
	{0, 3, 4, 6}, //20
	{1, 3, 4, 6}, //30
	{0, 2, 5, 6}, //40
	{1, 2, 5, 6}, //50
	{0, 3, 5, 6}, //60
	{1, 3, 5, 6}, //70
	{0, 2, 5, 7}, //80
	{1, 2, 5, 7}, //90
	{0, 3, 5, 7}, //100
	{1, 3, 5, 7}  //110
};

void set_sn74hc259_1(void) {
	PORTD |= (1<<PD3); // CLR1
	PORTD &= ~(1<<PD4); // EN1
	_delay_ms(10);
	PORTD |= (1<<PD4); // EN1
}

void set_sn74hc259_2(void) {
	PORTB |= (1<<PB0); // CLR2
	PORTB &= ~(1<<PB1); // EN2
	_delay_ms(10);
	PORTB |= (1<<PB1); // EN2
}

void clear_sn74hc259_1(void) {
	PORTD &= ~(1<<PD3);
	PORTD |= (1<<PD4);
}

void clear_sn74hc259_2(void) {
	PORTB &= ~(1<<PB0);
	PORTB |= (1<<PB1);
}

void set_att_1(int num) {
	clear_sn74hc259_1();
	for(int j=0;j<4;j++) {
		sn74hc259(x_db[num/10][j]);
		_delay_ms(10);
		set_sn74hc259_1();
	}
}

void set_att_2(int num) {
	clear_sn74hc259_2();
	for(int j=0;j<4;j++) {
		sn74hc259(x_db[num][j]);
		_delay_ms(10);
		set_sn74hc259_2();
	}
}

int main(void)
{
	DDRB = 0xff;
	DDRC = 0xff;
	DDRD = 0xff;
	DDRC &=~ (1<<PC0);
	DDRC &=~ (1<<PC1);
	DDRC &=~ (1<<PC2);
	PORTC |= (1 << PC2); //|(1 << PC1)|(1 << PC0);

	set_att_1(0); // default attenuator
	set_att_2(0);

	lcd_init(LCD_DISP_ON);
	lcd_gotoxy(18,3);
	lcd_puts("dB");
	lcd_gotoxy(18,6);
	lcd_puts("dB");
	/*att_int(68,5);
	att_int(82,5);
	att_int(96,5);
	att_int(96,37);*/
	lcd_charMode(DOUBLESIZE);
	lcd_gotoxy(0,2);
	lcd_puts("8496H");
	lcd_gotoxy(0,5);
	lcd_puts("8494H");
	lcd_gotoxy(15,2);
	lcd_puts("0");
	lcd_gotoxy(15,5);
	lcd_puts("0");
	lcd_charMode(NORMALSIZE);
	lcd_display();
	init_timer1();
	sei(); // global interrupt
	while (1)
    {
		_delay_ms(1);
	}
	return 0;
}
