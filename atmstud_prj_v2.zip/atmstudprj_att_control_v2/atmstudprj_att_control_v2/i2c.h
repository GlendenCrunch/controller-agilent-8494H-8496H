#ifndef i2c_h
#define i2c_h

#ifdef __cpluplus
extern "C" {
#endif

#define i2c_adress 0x78 // 0x3C << 1 = 0x78
#define F_I2C    400000UL
#define PSC_I2C  1
#define SET_TWBR (F_CPU/F_I2C-16UL)/(PSC_I2C*2UL)

#include <stdint.h>
#include <avr/io.h>
#include "main.h"

extern uint8_t I2C_ErrorCode;
#define I2C_START      0
#define I2C_SENDADRESS 1
#define I2C_BYTE       2

void i2c_init(void);
void i2c_start(uint8_t i2c_adr);
void i2c_stop(void);
void i2c_byte(uint8_t byte);

#ifdef __cplusplus
}
#endif
#endif
